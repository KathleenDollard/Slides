﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CorePuzzles
{
    [TestClass]
    public class Context
    {
        private const int expirationYears = 2;

        [TestMethod]
        public void Test_expiration()
        {
            var now = DateTime.Now;
            var expires = CalculateExpiration(now);
            Assert.IsTrue(expires > now);
        }

        public DateTime CalculateExpiration(DateTime startDate)
        {
            var expirationDate2 = startDate.AddYears(expirationYears);
            var expirationDate = new DateTime(
                    startDate.Year + expirationYears,
                    startDate.Month, startDate.Day);
            return expirationDate;
        }
    }
}
