﻿//using methods_and_overloads;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //        var testCode = new StringBuilderPuzzle();
            //        testCode.StringBuilderRace();

            //        //var thrower = new ExceptionThrower();
            //        //thrower.ThrowIt();
        }
    }
}
