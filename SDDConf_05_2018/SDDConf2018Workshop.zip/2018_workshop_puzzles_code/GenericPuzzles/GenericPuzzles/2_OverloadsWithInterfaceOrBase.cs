﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Generics
{
    public class BaseClass { }
    public class DerivedClass : BaseClass { }

    [TestClass]
    public class OverloadsWithInterfaceOrBase
    {
        [TestMethod]
        [TestCategory("Generics")]
        [TestCategory("Overloads")]
        public void GenericOverloadsTest()
        {
            var derivedClass = new DerivedClass();
            var baseClass = new BaseClass();
            BaseClass derivedClassAsBase = derivedClass;
 
            Assert.IsTrue(Test(derivedClass).StartsWith("Derived"));
            Assert.IsTrue(Test(baseClass).StartsWith("Base"));
            Assert.IsTrue(Test(derivedClassAsBase).StartsWith("Base"));
        }

        private string Test(BaseClass item) => "BaseClass version";
        private string Test(DerivedClass item) => "DerivedClass version";
    }
}
