Thanks for coming to my workshop. 

As you've discovered, I decided to put these slides where you can find them more easily.
I look forward to the day that everyone gets the Date math and decimal puzzles, and I'll 
just have to evolve my workshops if my secret puzzles get out ;-) (I'm saying that would 
be a good thing, just hard to let go.)

If you would like to work on a practice conversion and want to help with my evolution of 
the music store app, I will evaluate PRs. The goal on that is a step wise conversion with 
individual steps in separate commits, and PRs that aren't too big. That's at 
https://github.com/KathleenDollard/MVC-Music-Store (NOT the plain music store version).

I enjoyed having you in my class.

Kathleen