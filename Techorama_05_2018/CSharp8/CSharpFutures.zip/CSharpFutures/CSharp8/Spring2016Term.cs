﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharp7Demo
{
    public class Spring2016TermMessaging
    {
        public (IEnumerable<string> messages2, int staffCount) GetThankYouMessages
                (IEnumerable<Person> persons)
        {
            var messages = new List<string>();
            var fred = 0;
            foreach (var person in persons)
            {
                var message = GetThankYouMessage(person);

                var staff = person as Staff;
                if (staff != null)
                { fred += 1; }

                messages.Add(message);
            }
            return (messages, fred);
        }

        private string GetThankYouMessage(Person person)
        {
            switch (person)
            {
                case Student student3 when student3.GPA > 3.2m:
                    return $"Thanks {student3.Name} for being  an honor student this " +
                          $"term, sorry about the flood";
                case Student student3:
                    return $"Thanks {student3.Name} for being  an honor student this term, " +
                           $"sorry about the flood";
                case Instructor instructor2:
                    return $"Thanks for teaching {string.Join(", ", instructor2.Courses)}";
                case Staff staff2:
                    return $"Thanks for being a {staff2.StaffRole.ToString()}";
                case null:
                default:
                    throw new InvalidOperationException();
            }
        }

        public (IEnumerable<string> messages, int staffCount, int) GetThankYouMessages2(IEnumerable<Person> persons)
            =>
            (
                persons.Select(x => GetThankYouMessage2(x)),
                persons.Where(x => x is Staff).Count(),
                42
            );

        private string GetThankYouMessage2(Person person)
        => person switch
        {
            { Name: "John" } => "Where are the beers happening tonight?",
            Student student when (student.GPA > 3.2m)
            => $"Thanks {student.Name} for being  an honor student " +
               $"this term, sorry about the flood",
            Student student
            => "Thanks for being a student this term, sorry about the flood",
            Instructor instructor
            => $"Thanks for teaching {string.Join(", ", instructor.Courses)}",
            Staff staff
                => $"Thanks for being a {staff.StaffRole.ToString()}",
            _ =>
            throw new InvalidOperationException()
        };

        private string GetThankYouMessage3(Person person)
        => person switch
        {
            { Name: "John" } => "Where are the beers happening tonight?",
            Student student when (student.GPA > 3.2m)
            => $"Thanks {student.Name} for being  an honor student " +
               $"this term, sorry about the flood",
            Student student
            => "Thanks for being a student this term, sorry about the flood",
            Instructor instructor
            => $"Thanks for teaching {string.Join(", ", instructor.Courses)}",
            Staff staff
                => $"Thanks for being a {staff.StaffRole.ToString()}",
            _ =>
            throw new InvalidOperationException()
        };

        private string GetThankYouMessage4(Person person)
        => person switch
        {
            { Name: "John" } => "Where are the beers happening tonight?",
            Student student
                => (student.GPA > 3.2m)
                    ? $"Thanks {student.Name} for being  an honor student " +
                        $"this term, sorry about the flood"
                    : "Thanks for being a student this term, sorry about the flood",
            Instructor instructor
                => $"Thanks for teaching {string.Join(", ", instructor.Courses)}",
            Staff staff
                    => $"Thanks for being a {staff.StaffRole.ToString()}",
            _
                => throw new InvalidOperationException()
        };
    }
}
