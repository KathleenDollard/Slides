﻿namespace va
{
    internal class r
    {
    }
}