﻿using System;
using System.Linq;

namespace CSharp8Console
{
    class Program
    {

        static void Main(string[] args)
        {
            int[] ints = Enumerable.Range(0, 10).ToArray();
            Console.WriteLine(ints[0]);
            Console.WriteLine(ints[ints.Length - 1]);

            string s = "Hello World";
            Console.WriteLine(s.Substring(s.Length - 1));
            // starting at the third, take all but last
            Console.WriteLine(s.Substring(3, s.Length - 4));
            Console.Read();
        }
    }
}
