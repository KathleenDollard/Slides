﻿using System;

namespace CSharp8Console
{
    public static class NullableDemo
    {
        public static void RunDemo()
        {
            var person = new Person("Miguel", "de Icazza");
            Console.WriteLine(GetLengthOfMiddleName(person));
        }
        public static int GetLengthOfMiddleName(Person person)
        {
            string z = person.MiddleName;
            if (person == null || person.MiddleName == null)
            { return 0; }
            return person.MiddleName.Length;
        }
    }
}
