﻿using System;
using System.Collections.Generic;

namespace CSharp7Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            IDictionary<int, Person> persons = GetData();
            int staffCount;
            var term = new Spring2016TermMessaging();
            var messages = term.GetThankYouMessages(out staffCount,persons.Values  );

            Console.WriteLine("Staff count: {0}", messages);
            Console.Write(string.Join("\n", staffCount));
            Console.Read();

            string x = SomeUnknownMethod();
            int? y;
            if (x != null)
            {
                y = x.Length;
            }
            else
            {
                y = null;
            }
        }

        private static string SomeUnknownMethod() => null;

        private static IDictionary<Int32, Person> GetData()
        {
            ISeedData<Person> seedData = new SeedDataForPerson();
            return seedData.GetData();
        }

        private static Person GetPerson(
                        IDictionary<int, Person> persons, int id)
        {
            return persons[id];
        }
    }
}
