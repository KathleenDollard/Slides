﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSharp7Demo
{
    class Program
    {
        // Async main to demo usage, don't use except when you are awaiting
        public static async Task Main(string[] args)
        {
            IDictionary<int, Person> persons = GetData();
            var term = new Spring2016TermMessaging();
            var (Messages, StaffCount) = 
                term.GetThankYouMessages( persons.Values);

            Console.WriteLine("Staff count: {0}", Messages);
            Console.Write(string.Join("\n", StaffCount));
            Console.Read();

            var mArray = Messages.ToArray();
            var firstMessage = mArray[0];
            var lastMessage = mArray[mArray.Length - 1];
            var lastMessageCool = mArray[^1];

            // Default literals
            var z = default(Spring2016TermMessaging);
            Spring2016TermMessaging z2 = default;

            string x = SomeUnknownMethod();
            int? y = x?.Length;

            string zz = Foo(Fred: x, y);


  
        }

        private static string Foo(string Fred, int? George) => throw new NotImplementedException();
        private static string SomeUnknownMethod() => null;

        private static IDictionary<Int32, Person> GetData()
        {
            ISeedData<Person> seedData = new SeedDataForPerson();
            return seedData.GetData();
        }

        private static Person GetPerson(
                        IDictionary<int, Person> persons, int id) => persons[id];
    }
}
