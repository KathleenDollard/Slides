﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharp7Demo
{
    public class Spring2016TermMessaging
    {
        public (IEnumerable<string> Messages, int StaffCount)
            GetThankYouMessages(IEnumerable<Person> persons)
        {
            var messages = persons.Select(p => GetThankYouMessage(p));

            int staffCount = persons.Count(p => p is Staff);

            return (messages, staffCount);
        }

        private string GetThankYouMessage(Person person)
        {
            switch (person)
            {
                case Student student when student.GPA > 3.2m:
                    return $"Thanks {student.Name} for being  an honor student this term, " +
                               $"sorry about the flood";
                case Student student:
                    return $"{student.Name} term, sorry about the flood";
                case Instructor instructor:
                    return $"Thanks for teaching {string.Join(", ", instructor.Courses)}";
                case Staff staff:
                    return $"Thanks for being a {staff.StaffRole.ToString()}";
                default:
                    throw new InvalidOperationException();
            }
        }



    }
}

