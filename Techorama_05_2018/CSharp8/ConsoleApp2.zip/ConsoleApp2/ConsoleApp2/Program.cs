﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = "".Extension();
            Console.WriteLine("Hello World!");
        }
    }

    public static class A
    {
        public static int Extension(this string value) => 42;
        public static int Extension<T>(this T value)
            where T : struct => 42;
    }

    public static class B
    {
        public static int Extension<T>(this T value)
            where T : class => 46;
    }
}
