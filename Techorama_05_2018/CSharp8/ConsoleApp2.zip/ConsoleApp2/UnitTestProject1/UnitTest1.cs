﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ApprovalTests;
using ApprovalTests.Reporters;

namespace UnitTestProject1
{
    [TestClass]
    [UseReporter(typeof(DiffReporter), typeof(ClipboardReporter))]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1() => Approvals.Verify(GetHello());

        private static string GetHello() => "Hello!";
    }
}
