﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using static KadGen.Functional.Common.Constants;

namespace KadGen.Functional.Common
{
    public abstract class Outcome
    {
        // Expected use is to create a new RichData with the union of previous and new issues
        protected Outcome(IEnumerable<IssueBase> issues)
           => Issues = issues.ToImmutableList();

        protected Outcome(params IssueBase[] issues)
          => Issues = issues.ToImmutableList();

        public abstract ResultStatus ResultStatus { get; }

        public ImmutableList<IssueBase> Issues { get; }
    }

    #region Error classes
    public abstract class ErrorOutcome : Outcome
    {
        protected ErrorOutcome(IEnumerable<IssueBase> issues)
        : base(issues) { }

        protected ErrorOutcome(params IssueBase[] issues)
        : base(issues) { }

        public override ResultStatus ResultStatus { get; } = Fail;
    }

    public class ExceptionFailOutcome : ErrorOutcome
    {
        public ExceptionFailOutcome(Exception ex)
        : base(new ExceptionIssue(ex)) { }
    }

    public class ValidationFailOutcome : ErrorOutcome
    {
        public ValidationFailOutcome(params ValidationIssue[] validationIssues)
        : base(validationIssues) => ValidationIssues = validationIssues;

        public IEnumerable<ValidationIssue> ValidationIssues { get; }
            = new List<ValidationIssue>();
    }

    public class BatchFailOutcome : ErrorOutcome
    {
        // TODO
    }
    #endregion

    #region Warning classes
    // Warnings and Info are different because I kept thinking of the 
    // Visual Studio feature "Treat warnings as errors" and wanted outer
    // infrastructure to be able to do something like that
    public class WarningOutcome : Outcome
    {
        protected WarningOutcome(IEnumerable<IssueBase> issues)
         : base(issues) { }

        public override ResultStatus ResultStatus { get; } = Success;
    }
    #endregion

    #region Info classes
    public class InfoOutcome : Outcome
    {
        protected InfoOutcome(IEnumerable<IssueBase> issues)
        : base(issues) { }

        public override ResultStatus ResultStatus { get; } = Success;

        // Probably want to add verbosity, which means either multiple classes
        // or, more likely, a parameterized constructor here. 
    }
    #endregion

}