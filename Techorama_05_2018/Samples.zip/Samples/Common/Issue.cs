﻿using System;
using System.Collections.Generic;

namespace KadGen.Functional.Common
{

    public abstract class IssueBase
    {
        public abstract string UserMessage { get; }      // must be capable of giving a user message
        public virtual string LogMessage => UserMessage; // may also provide a programmer message
    }

    public class StringIssue : IssueBase
    {
        public StringIssue(string issue)
        => UserMessage = issue;

        public override string UserMessage { get; }
    }

    public class ExceptionIssue : IssueBase
    {
        public readonly static string ExceptionHappened = "Oops"; // suggest you work a bit harder here
        public ExceptionIssue(Exception ex)
        => Exception = ex;

        public ExceptionIssue(Exception ex, string userMessage)
        => Exception = ex;

        public Exception Exception { get; }

        public override string UserMessage
        => ExceptionHappened;

        public override string LogMessage
        => Exception.ToString();
    }

    public class ValidationIssue : IssueBase
    {
        public ValidationIssue(ValidationIssueId issueId, params string[] fieldNames)
        {
            ValidationIssueId = issueId;
            FieldNames = fieldNames;
        }

        public ValidationIssueId ValidationIssueId { get; }
        public IEnumerable<string> FieldNames { get; } //normally contains one

        // TODO: Provide real message
        public override string UserMessage => "Validation error";
    }

    public enum ValidationIssueId
    {
        Unknown = 0,
        RequiredValueMissing,
        StringTooShort
    }

}
