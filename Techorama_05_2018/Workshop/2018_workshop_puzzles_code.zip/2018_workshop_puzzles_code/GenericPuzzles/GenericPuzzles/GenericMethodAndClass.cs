﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericPuzzles
{
   public class Dummy
   {
      public void Bar()
      {
         //GenericClass<string>.Foo("Hello World");
         //GenericClass<string>.Foo2(42);
         //NonGenericClass.Foo("Hello World");
         //NonGenericClass.Foo2(42);
      }
   }

   public class GenericClass<T>
   {
      public static void Foo(T param) { }
      public static void Foo2(T param) { }
      public static void Foo3(T param) { }
   }

   public class NonGenericClass
   {
      public static void Foo<T>(T param) { }
      public static void Foo2<T>(T param) { }
      public static void Foo3<T>(T param) { }
   }
}
