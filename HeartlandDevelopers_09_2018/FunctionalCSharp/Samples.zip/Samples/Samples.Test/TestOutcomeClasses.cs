﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Samples.Test
{
    [TestClass]
    public class TestOutcomeClasses
    {
        [TestMethod]
        public void Can_create_success_with_data()
        {
            var x = new RichData<int>();
        }
    }
}
