﻿using System;
using System.Linq;
using KadGen.Functional.Common;

namespace KadGen.Functional.Samples
{
    public class InsideOutProgramming
    {
        #region initial code
        public int FooStarting(int x, int y)
        {
            try
            {
                using (var dbContext = new CTDbContext(Utilities.GetConnString()))
                {
                    return dbContext.Courses.Count() + x + y;
                }
            }
            catch
            {
                return -1; // Don't do this, it's a stupid sample
            }
        }
        #endregion

        #region refactored with using
        public int Foo(int x, int y)
        {
            try
            {
                return Using(
                    () => new CTDbContext(Utilities.GetConnString()),
                    d => d.Courses.Count() + x + y);
            }
            catch
            {
                return -1; // Don't do this, it's a stupid sample
            }
        }

        public TReturn Using <TReturn, TDisposable>(
            Func<TDisposable > getDisposable,
            Func<TDisposable, TReturn > operation)
            where TDisposable : IDisposable 
        {
            using (TDisposable disposable = getDisposable())
            {
                return operation(disposable);
            }
        }
        #endregion

        #region Refactored with Try
        public static TRichData Try<TRichData>(
            Func<TRichData> operate,
            Func<Exception, TRichData> catchOperate)
        {
            try
            {
                return operate();
            }
            catch (Exception ex)
            {
                return catchOperate(ex);
            }
        }
        #endregion

        // This is the demo I cut short. 
        public int Foo2(int x, int y)
         => Handling.WithDemoHandling(
                () => Disposable.Using(
                    () => new CTDbContext(Utilities.GetConnString()),
                    disp => disp.Courses.Count() + x + y));
        
        // Here is the same demo returning a data result via implicit operator conversion
        public RichData<int> Foo3(int x, int y) 
            => Handling.WithCommonHandling(
                () => Disposable.Using(
                    () => new CTDbContext(Utilities.GetConnString()),
                    disp => (RichData<int>)(disp.Courses.Count() + x + y)));
        }   
    }
